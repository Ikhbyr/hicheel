package sample;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import sample.newAutoPart.newAutoPartController;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Controller {
    public TextField txtOrderTotal;
    public TextField txtPartsTotal;
    public TextField txtTaxRate;
    public TextField txtTaxAmount;
    public TextField txtSave;
    public TextField txtOpen;

    public TableView tvSelectedParts;
    public TableColumn colPartNumberSelected;
    public TableColumn colPartNameSelected;
    public TableColumn colUnitPriceSelected;
    public TableColumn colQuantitySelected;
    public TableColumn colSubTotalSelected;


    public TextField txtSubTotal;
    public TextField txtQuantity;
    public TextField txtUnitPrice;
    public TextField txtPartName;
    public TextField txtPartNumber;

    public TableView tvAutoParts;
    public TableColumn colPartNumber;
    public TableColumn colPartName;
    public TableColumn colUnitPrice;

    public TreeView tvwAutoParts;
    public static AutoPart selectedPart = null;
    public static Statement statement;

    private final ObservableList<AutoPart> availableParts = FXCollections.observableArrayList();
    private final ObservableList<OrderParts> selectedParts = FXCollections.observableArrayList();

    public void initialize(){

        DatabaseControl.createDatabase();


        txtSubTotal.setDisable(true);
        txtQuantity.setDisable(true);
        txtPartNumber.setDisable(true);
        txtPartName.setDisable(true);
        txtUnitPrice.setDisable(true);

        txtSubTotal.setEditable(false);
        txtQuantity.setEditable(false);
        txtPartNumber.setEditable(false);
        txtPartName.setEditable(false);
        txtUnitPrice.setEditable(false);


        txtUnitPrice.setText("0.00");
        txtQuantity.setText("0");
        txtSubTotal.setText("0.00");

        txtTaxRate.setText("7.75");
        txtTaxAmount.setText("0.00");
        txtPartsTotal.setText("0.00");
        txtOrderTotal.setText("0.00");

        TreeItem rootItem = new TreeItem("College Parks Auto Parts");
        for (int i=2000 ; i<=2020; i++){
            rootItem.getChildren().add(new TreeItem(i));
        }

        tvwAutoParts.setRoot(rootItem);


        colPartNumber.setCellValueFactory(new PropertyValueFactory<>("number"));
        colPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colUnitPrice.setCellValueFactory(new PropertyValueFactory<>("price"));

        tvAutoParts.setItems(availableParts);


        colPartNumberSelected.setCellValueFactory(new PropertyValueFactory<>("number"));
        colPartNameSelected.setCellValueFactory(new PropertyValueFactory<>("name"));
        colUnitPriceSelected.setCellValueFactory(new PropertyValueFactory<>("price"));
        colQuantitySelected.setCellValueFactory(new PropertyValueFactory<>("qty"));
        colSubTotalSelected.setCellValueFactory(new PropertyValueFactory<>("subTotal"));

        tvSelectedParts.setItems(selectedParts);


        try {
            statement = ConnectDB.connectDb();
            statement.execute("USE CollegeParkAutoParts");
            ResultSet result = statement.executeQuery("SELECT * FROM autoparts");

            while (result.next()){
                String number = result.getString("PartNumber");
                String year = result.getString("CarYear");
                String make = result.getString("Make");
                String model = result.getString("Model");
                String partNumber = result.getString("PartNumber");
                String category = result.getString("Category");
                String partName = result.getString("PartName");
                Double unitPrice = result.getDouble("UnitPrice");

                AutoPart part = new AutoPart(number, make, model, category, partName, unitPrice);

                TreeItem subRootbyYear = getTreeViewItem(rootItem, year);
                TreeItem subRootbyMake = getTreeViewItem(subRootbyYear, make);

                if (subRootbyMake != null){
                    TreeItem subRootbyModel = getTreeViewItem(subRootbyMake, model);

                    if (subRootbyModel != null){
                        subRootbyModel.getChildren().add(new TreeItem<AutoPart>(part));
                    }else {
                        subRootbyMake.getChildren().add(new TreeItem(model));
                    }

                }else {
                    subRootbyYear.getChildren().add(new TreeItem(make));
                    TreeItem subRootbyMakeNew = getTreeViewItem(subRootbyYear, make);
                    subRootbyMakeNew.getChildren().add(new TreeItem<>(model));
                    TreeItem subRootbyModelNew = getTreeViewItem(subRootbyMakeNew, model);
                    subRootbyModelNew.getChildren().add(new TreeItem<AutoPart>(part));
                }

            }

            ResultSet idResult = statement.executeQuery("SELECT CustomerOrderID FROM customersorders ORDER BY CustomerOrderID DESC LIMIT 1;");
            if (idResult.next() == false) { System.out.println("ResultSet in empty in Java"); }



        }catch (SQLException | NullPointerException ex){
            System.out.println(ex.getMessage());
            ex.printStackTrace();
        }


        tvwAutoParts.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                if(mouseEvent.getButton().equals(MouseButton.PRIMARY)){
                    if(mouseEvent.getClickCount() == 2){
                        try {
                            TreeItem tr = (TreeItem) tvwAutoParts.getSelectionModel().getSelectedItem();
                            AutoPart part = (AutoPart) tr.getValue();
                            if (!availableParts.contains(part)) {
                                availableParts.add(part);
                            }
                        }catch (ClassCastException | NullPointerException ex){
                            System.out.println(ex.getMessage());
                        }
                    }
                }
            }
        });


        tvAutoParts.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (event.isPrimaryButtonDown() && event.getClickCount() == 2) {
                    if (txtQuantity.isEditable()) {
                        try {
                            System.out.println();
                            selectedPart = (AutoPart) tvAutoParts.getSelectionModel().getSelectedItem();

                            txtPartNumber.textProperty().bind(selectedPart.numberProperty());
                            txtPartName.textProperty().bind(selectedPart.nameProperty());
                            txtUnitPrice.textProperty().bind(new SimpleStringProperty(String.valueOf(selectedPart.getPrice())));
                            txtQuantity.setText("1");
                        } catch (NullPointerException ex) {
                            System.out.println(ex.getMessage());
                        }
                    }
                }
            }
        });

        txtQuantity.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.equals("")){
                double subtotal = Double.parseDouble(txtUnitPrice.getText()) * Double.parseDouble(newValue);

                txtSubTotal.textProperty().bind(new SimpleStringProperty(String.format("%.2f", subtotal)));
            }
        });


    }

    public static TreeItem getTreeViewItem(TreeItem item , String value)
    {
        for (int i=0; i < item.getChildren().size(); i++){
            TreeItem it = (TreeItem) item.getChildren().get(i);

            if (value.equals(it.getValue().toString())){
                return it;
            }
        }
        return null;
    }


    public void btnNewAutoPart(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("newAutoPart/newAutoPart.fxml"));
            Parent root = (Parent) loader.load();
            newAutoPartController newAutoPartController = loader.getController();
            Stage stage = new Stage();
            stage.centerOnScreen();
            stage.setResizable(false);
            stage.setScene(new Scene(root));
            stage.setTitle("College Park Auto-Parts: Part Editor");
            stage.show();
        }catch (IOException ex){
            ex.printStackTrace();
        }
    }

    public void btnClose(ActionEvent actionEvent) throws SQLException {

        ConnectDB.disconnectDb();
        Node source = (Node)  actionEvent.getSource();
        Stage stage  = (Stage) source.getScene().getWindow();
        stage.close();
    }

    public void btnOpen(ActionEvent actionEvent) {
    }

    public void btnSave(ActionEvent actionEvent) {
    }

    public void btnNewCustomerOrder(ActionEvent actionEvent) {
        txtSubTotal.setDisable(false);
        txtQuantity.setDisable(false);
        txtPartNumber.setDisable(false);
        txtPartName.setDisable(false);
        txtUnitPrice.setDisable(false);

        txtSubTotal.setEditable(true);
        txtQuantity.setEditable(true);
        txtPartNumber.setEditable(true);
        txtPartName.setEditable(true);
        txtUnitPrice.setEditable(true);
    }

    public boolean checkDuplicate(ObservableList<OrderParts> orderList, OrderParts order){
        for(OrderParts o : orderList){
             if(order.compareTo(o) > 0)
                 return true;
        }
        return false;
    }

    public void btnAdd(ActionEvent actionEvent) {
        OrderParts order = new OrderParts(selectedPart.getNumber(), selectedPart.getMake(), selectedPart.getModel(), selectedPart.getCategory(), selectedPart.getName(), selectedPart.getPrice(), Integer.parseInt(txtQuantity.getText()), Double.parseDouble(txtSubTotal.getText()));

        if (!checkDuplicate(selectedParts, order)) {
            selectedParts.add(order);
        }

    }
}
