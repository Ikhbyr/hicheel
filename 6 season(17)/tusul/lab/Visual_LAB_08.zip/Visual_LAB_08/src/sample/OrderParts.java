package sample;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import sample.AutoPart;

public class OrderParts extends AutoPart implements Comparable<OrderParts> {
    SimpleIntegerProperty qty = new SimpleIntegerProperty();
    SimpleDoubleProperty subTotal = new SimpleDoubleProperty();


    public OrderParts(SimpleStringProperty number, SimpleStringProperty make, SimpleStringProperty model, SimpleStringProperty category, SimpleStringProperty description, SimpleDoubleProperty price, SimpleIntegerProperty qty, SimpleDoubleProperty subTotal) {
        super(number, make, model, category, description, price);
        this.qty = qty;
        this.subTotal = subTotal;
    }

    public OrderParts(String number, String make, String model, String category, String description, Double price, int qty, double subTotal) {
        super(number, make, model, category, description, price);
        setQty(qty);
        setSubTotal(subTotal);
    }


    public int getQty() {
        return qty.get();
    }

    public SimpleIntegerProperty qtyProperty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty.set(qty);
    }

    public double getSubTotal() {
        return subTotal.get();
    }

    public SimpleDoubleProperty subTotalProperty() {
        return subTotal;
    }

    public void setSubTotal(double subTotal) {
        this.subTotal.set(subTotal);
    }

    @Override
    public String toString() {
        return qty + ", " + subTotal + ", " + super.toString();
    }

    @Override
    public int compareTo(OrderParts o) {
        if(getNumber().equals(o.getNumber()))
            return 1;
        else
            return 0;

    }
}
