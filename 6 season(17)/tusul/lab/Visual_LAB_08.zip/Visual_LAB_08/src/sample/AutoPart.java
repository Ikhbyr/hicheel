package sample;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;

public class AutoPart {
    SimpleStringProperty number = new SimpleStringProperty();
    SimpleStringProperty make = new SimpleStringProperty();
    SimpleStringProperty model = new SimpleStringProperty();
    SimpleStringProperty category = new SimpleStringProperty();
    SimpleStringProperty name = new SimpleStringProperty();
    SimpleDoubleProperty price = new SimpleDoubleProperty();

    public AutoPart(SimpleStringProperty number, SimpleStringProperty make, SimpleStringProperty model, SimpleStringProperty category, SimpleStringProperty description, SimpleDoubleProperty price) {
        this.number = number;
        this.make = make;
        this.model = model;
        this.category = category;
        this.name = description;
        this.price = price;
    }

    public AutoPart(String number,String make, String model, String category, String description, Double price) {
        setNumber(number);
        setMake(make);
        setModel(model);
        setCategory(category);
        setName(description);
        setPrice(price);
    }

    public String getNumber() {
        return number.get();
    }

    public SimpleStringProperty numberProperty() {
        return number;
    }

    public void setNumber(String number) {
        this.number.set(number);
    }

    public String getMake() {
        return make.get();
    }

    public SimpleStringProperty makeProperty() {
        return make;
    }

    public void setMake(String make) {
        this.make.set(make);
    }

    public String getModel() {
        return model.get();
    }

    public SimpleStringProperty modelProperty() {
        return model;
    }

    public void setModel(String model) {
        this.model.set(model);
    }

    public String getCategory() {
        return category.get();
    }

    public SimpleStringProperty categoryProperty() {
        return category;
    }

    public void setCategory(String category) {
        this.category.set(category);
    }

    public String getName() {
        return name.get();
    }

    public SimpleStringProperty nameProperty() {
        return name;
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public double getPrice() {
        return price.get();
    }

    public SimpleDoubleProperty priceProperty() {
        return price;
    }

    public void setPrice(double price) {
        this.price.set(price);
    }

    @Override
    public String toString() {
        return  getMake() + "," + getModel() + "," + getCategory() + "," + getName() + "," + getPrice() ;
    }


}
