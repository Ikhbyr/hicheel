package sample.newAutoPart;

import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import sample.Controller;
import sample.newAutoPart.newCategory.newCategoryController;
import sample.newAutoPart.newMake.newMakeController;
import sample.newAutoPart.newModel.newModelController;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class newAutoPartController {
    public TextField txtPartName;
    public TextField txtUnitPrice;
    public ComboBox cbxCategories;
    public ComboBox cbxModels;
    public ComboBox cbxMakes;
    public ComboBox cbxYear;
    public TextField txtPartNumber;


    public static ObservableList<String> makes = FXCollections.observableArrayList();
    public static ObservableList<String> models = FXCollections.observableArrayList();
    public static ObservableList<String> categories = FXCollections.observableArrayList();


    public void initialize(){
        txtUnitPrice.setText("0.00");
        clearComboboxDate();
        try {
            String sql = "SELECT * FROM Make";
            ResultSet resultMake = Controller.statement.executeQuery(sql);
            while (resultMake.next()){
                makes.add(resultMake.getString("make"));
            }

            String sql2 = "SELECT * FROM Model";
            ResultSet resultModel = Controller.statement.executeQuery(sql2);
            while (resultModel.next()){
                models.add(resultModel.getString("model"));
            }

            String sql3 = "SELECT * FROM Category";
            ResultSet resultCategory = Controller.statement.executeQuery(sql3);
            while (resultCategory.next()){
                categories.add(resultCategory.getString("category"));
            }

            for (int i=2000; i<=2020; i++){
                cbxYear.getItems().add(i);
            }

            setComboboxData();
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }

        makes.addListener(new ListChangeListener<String>() {
            @Override
            public void onChanged(Change<? extends String> change) {
                setComboboxData();
            }
        });

        models.addListener(new ListChangeListener<String>() {
            @Override
            public void onChanged(Change<? extends String> change) {
                setComboboxData();
            }
        });

        categories.addListener(new ListChangeListener<String>() {
            @Override
            public void onChanged(Change<? extends String> change) {
                setComboboxData();
            }
        });

    }

    public void clearComboboxDate(){
        makes.clear();
        models.clear();
        categories.clear();
    }

    public void setComboboxData(){
        cbxModels.getItems().clear();
        cbxMakes.getItems().clear();
        cbxCategories.getItems().clear();

        cbxModels.getItems().addAll(models);
        cbxMakes.getItems().addAll(makes);
        cbxCategories.getItems().addAll(categories);
    }

    public void btnClose(ActionEvent actionEvent) {
        Node source = (Node)  actionEvent.getSource();
        Stage stage  = (Stage) source.getScene().getWindow();
        stage.close();
    }

    public void btnSubmit(ActionEvent actionEvent) {
        try {
                String year = cbxYear.getSelectionModel().getSelectedItem().toString();
                String make = cbxMakes.getSelectionModel().getSelectedItem().toString();
                String model = cbxModels.getSelectionModel().getSelectedItem().toString();
                String categories = cbxCategories.getSelectionModel().getSelectedItem().toString();
                String partName = txtPartName.getText();
                String partNumber = txtPartNumber.getText();
                String partPrice = txtUnitPrice.getText();
                if (!partName.equals("") && !partNumber.equals("") && !partPrice.equals("")){
                    Controller.statement.execute("INSERT INTO autoparts(PartNumber, CarYear, Make, Model, Category, PartName, UnitPrice) VALUES(" + partNumber + "," + year + ",'" + make + "','" + model + "','" + categories + "' , '" + partName + "' , " + partPrice + ")");
                }

        }catch (NullPointerException | SQLException ex){
            System.out.println(ex.getMessage());
        }

        Node source = (Node)  actionEvent.getSource();
        Stage stage  = (Stage) source.getScene().getWindow();
        stage.close();

    }


    public void btnNewMake(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("newMake/newMake.fxml"));
            Parent root = (Parent) loader.load();
            newMakeController newMakeController = loader.getController();
            Stage stage = new Stage();
            stage.centerOnScreen();
            stage.setResizable(false);
            stage.setScene(new Scene(root));
            stage.setTitle("Make Editor");
            stage.show();
        }catch (IOException ex){
            ex.printStackTrace();
        }
    }

    public void btnNewModel(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("newModel/newModel.fxml"));
            Parent root = (Parent) loader.load();
            newModelController newModelController = loader.getController();
            Stage stage = new Stage();
            stage.centerOnScreen();
            stage.setResizable(false);
            stage.setScene(new Scene(root));
            stage.setTitle("Model Editor");
            stage.show();
        }catch (IOException ex){
            ex.printStackTrace();
        }
    }

    public void btnNewCategoru(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("newCategory/newCategory.fxml"));
            Parent root = (Parent) loader.load();
            newCategoryController newCategoryController  = loader.getController();
            Stage stage = new Stage();
            stage.centerOnScreen();
            stage.setResizable(false);
            stage.setScene(new Scene(root));
            stage.setTitle("Item Category");
            stage.show();
        }catch (IOException ex){
            ex.printStackTrace();
        }
    }
}
