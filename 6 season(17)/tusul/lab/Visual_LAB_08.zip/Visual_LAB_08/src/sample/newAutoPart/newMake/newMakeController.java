package sample.newAutoPart.newMake;

import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import sample.Controller;
import sample.newAutoPart.newAutoPartController;

import java.sql.SQLException;

public class newMakeController {
    public TextField txtMake;

    public void btnOK(ActionEvent actionEvent) {
        try {
            if (!txtMake.getText().equals("")) {
                String make = txtMake.getText();
                Controller.statement.execute("INSERT INTO Make VALUES('" + make + "')");
                newAutoPartController.makes.add(make);
            }
        }catch (SQLException ex){
            System.out.println(ex.getMessage());
        }finally {
            Node source = (Node)  actionEvent.getSource();
            Stage stage  = (Stage) source.getScene().getWindow();
            stage.close();
        }
    }

    public void btnCancel(ActionEvent actionEvent) {
        Node source = (Node)  actionEvent.getSource();
        Stage stage  = (Stage) source.getScene().getWindow();
        stage.close();
    }
}
