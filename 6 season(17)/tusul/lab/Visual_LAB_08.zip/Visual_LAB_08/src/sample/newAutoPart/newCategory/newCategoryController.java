package sample.newAutoPart.newCategory;

import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import sample.Controller;
import sample.newAutoPart.newAutoPartController;

import java.sql.SQLException;

public class newCategoryController {
    public TextField txtCategory;

    public void btnOK(ActionEvent actionEvent) {
        try {
            if (!txtCategory.getText().equals("")) {
                String category = txtCategory.getText();
                Controller.statement.execute("INSERT INTO Category VALUES('" + category + "')");
                newAutoPartController.categories.add(category);
            }
        }catch (SQLException ex){
            System.out.println(ex.getMessage());
        }finally {
            Node source = (Node)  actionEvent.getSource();
            Stage stage  = (Stage) source.getScene().getWindow();
            stage.close();
        }
    }

    public void btnCancel(ActionEvent actionEvent) {
        Node source = (Node)  actionEvent.getSource();
        Stage stage  = (Stage) source.getScene().getWindow();
        stage.close();
    }
}
