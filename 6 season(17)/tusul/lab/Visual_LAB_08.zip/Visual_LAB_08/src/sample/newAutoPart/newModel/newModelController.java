package sample.newAutoPart.newModel;

import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import sample.Controller;
import sample.newAutoPart.newAutoPartController;

import java.sql.SQLException;

public class newModelController {
    public TextField txtModel;

    public void btnOK(ActionEvent actionEvent)  {
        try {
            if (!txtModel.getText().equals("")) {
                String model = txtModel.getText();
                Controller.statement.execute("INSERT INTO Model VALUES('" + model + "')");
                newAutoPartController.models.add(model);
            }
        }catch (SQLException ex){
            System.out.println(ex.getMessage());
        }finally {
            Node source = (Node)  actionEvent.getSource();
            Stage stage  = (Stage) source.getScene().getWindow();
            stage.close();
        }

    }

    public void btnCancel(ActionEvent actionEvent) {
        Node source = (Node)  actionEvent.getSource();
        Stage stage  = (Stage) source.getScene().getWindow();
        stage.close();
    }
}
