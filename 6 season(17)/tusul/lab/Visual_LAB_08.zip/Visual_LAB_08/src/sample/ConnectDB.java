package sample;

import javax.swing.plaf.nimbus.State;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnectDB {
    public static Connection connection;
    public static Statement statement;

    public static Statement connectDb() {

        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost/?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC", "root", "root");
            System.out.println("MySQL server Connected");
            statement = connection.createStatement();


            return statement;
        } catch (Exception ex) {
            System.out.println("DB Failed");
            System.out.println(ex.getMessage());
        }
        return null;
    }

    public static void disconnectDb() {
        try {
            connection.close();
            System.out.println("Connection closed.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

