package sample;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Objects;

public class DatabaseControl {

    public static Statement statement;
    public static Connection connection;


    public static void createDatabase() {
        try {
            statement = ConnectDB.connectDb();


            statement.execute("CREATE DATABASE IF NOT EXISTS CollegeParkAutoParts");

            statement.execute("USE CollegeParkAutoParts");


            statement.execute("CREATE TABLE AutoParts(" +
                    "PartNumber int NOT NULL PRIMARY KEY, " +
                    "CarYear int, " +
                    "Make varchar(50), " +
                    "Model varchar(50), " +
                    "Category varchar(50), " +
                    "PartName varchar(100), " +
                    "UnitPrice double);");

            statement.execute("CREATE TABLE CustomersOrders(" +
                    "CustomerOrderID int NOT NULL  PRIMARY KEY AUTO_INCREMENT, " +
                    "ReceiptNumber int NOT NULL, " +
                    "PartNumber int NULL, " +
                    "PartName varchar(100), " +
                    "UnitPrice double, " +
                    "Quantity int, " +
                    "SubTotal double, " +
                    "PartsTotal double, " +
                    "TaxRate decimal(6, 2), " +
                    "TaxAmount double, " +
                    "OrderTotal double);");

            statement.execute("ALTER TABLE CustomersOrders AUTO_INCREMENT=1000");

            statement.execute("CREATE TABLE Make(" +
                    "make varchar(100) NOT NULL)");

            statement.execute("CREATE TABLE Model(" +
                    "model varchar(100) NOT NULL)");

            statement.execute("CREATE TABLE Category(" +
                    "category varchar(100) NOT NULL)");

        }catch (SQLException | NullPointerException ex){
            System.out.println(ex.getMessage());
        }finally {
            ConnectDB.disconnectDb();
        }
    }
}
